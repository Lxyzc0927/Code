"""Recompute CUMCM A with conservative radial finite volumes and SciPy BDF.

Run with Python plus numpy, scipy, openpyxl. The original inputs are read only.
Temperature state is Celsius, converted to Kelvin only in Arrhenius factors.
For Q4 x=r/R(t) is a fixed material coordinate under uniform shrinkage.
No concentration clipping, explicit CFL relaxation, density weighting of C,
or duplicate mesh-advection/dilution term is used.
"""

from pathlib import Path
import argparse, json, math, time, shutil, hashlib
from scipy.special import expi
from scipy.integrate import quad
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse import lil_matrix
from openpyxl import load_workbook

BASE = None
WORK = None
DEST = None
ENV = None
RAD = None
HT, HM, TARGET = 25.0, 8e-7, 0.15


def read_input(name, width):
    with_path = BASE / "附件" / name
    wb = load_workbook(with_path, read_only=True, data_only=True)
    rows = [list(r[:width]) for r in wb.active.iter_rows(values_only=True)][1:]
    wb.close()
    a = np.asarray(rows, dtype=float)
    assert np.isfinite(a).all() and np.all(np.diff(a[:, 0]) > 0) and a[0, 0] == 0
    return a


def configure(input_dir, output_dir):
    global BASE, WORK, DEST, ENV, RAD
    BASE = Path(input_dir).resolve()
    WORK = Path(output_dir).resolve()
    WORK.mkdir(parents=True, exist_ok=True)
    DEST = WORK
    ENV = read_input("附件1.xlsx", 3)
    RAD = read_input("附件2.xlsx", 2)
    assert ENV[0, 1] == 28 and RAD[0, 1] == 2 and (RAD[:, 1] > 0).all()


def phi(C, b):
    return C * np.exp(-b / C) + b * expi(-b / C)


def moisture_parameters(q, T):
    if q == 1:
        return np.asarray(T) * 0 + 7e-9, 0.89
    if q == 3:
        return 2.4e-3 * np.exp(-3850 / (T + 273.15)), 0.45
    if q == 4:
        return 4.2e-4 * np.exp(-3850 / (T + 273.15)), 0.30
    raise ValueError(q)


def radius(q, t):
    return (
        np.interp(t, RAD[:, 0], RAD[:, 1]) * 0.01
        if q == 4
        else np.asarray(t) * 0 + 0.02
    )


def props(q, T, C):
    if q == 1:
        return (
            np.full_like(C, 820 * 2600),
            np.full_like(C, 0.36),
            7e-9 * np.exp(-0.89 / C),
        )
    if q == 3:
        return (
            (650 + 128 * C) * (1450 + 2736 * C / (C + 1)),
            0.21 + 0.38 * C / (C + 1),
            2.4e-3 * np.exp(-0.45 / C) * np.exp(-3850 / (T + 273.15)),
        )
    if q == 4:
        return (
            (760 + 90 * C) * (1850 + 2150 * C / (C + 1)),
            0.12 + 0.20 * C / (C + 1),
            4.2e-4 * np.exp(-0.30 / C) * np.exp(-3850 / (T + 273.15)),
        )
    raise ValueError(q)


def model(q, n, moisture_flux="integrated"):
    x = np.linspace(0, 1, n)
    faces = np.r_[0, (x[:-1] + x[1:]) / 2, 1]
    vol = (faces[1:] ** 2 - faces[:-1] ** 2) / 2
    dx = x[1] - x[0]

    def flux_div(u, a, ambient, h, R):
        harmonic = 2 * a[:-1] * a[1:] / (a[:-1] + a[1:])
        flux = np.zeros(n + 1)
        flux[1:-1] = faces[1:-1] * harmonic * np.diff(u) / dx
        flux[-1] = R * h * (ambient - u[-1])
        return np.diff(flux) / (R * R * vol)

    def rhs(t, y):
        T, C = y[:n], y[n:]
        cap, k, D = props(q, T, C)
        R = float(radius(q, t))
        Ta = np.interp(t, ENV[:, 0], ENV[:, 1])
        Ca = np.interp(t, ENV[:, 0], ENV[:, 2])
        if moisture_flux == "harmonic":
            dC = flux_div(C, D, Ca, HM, R)
        else:
            A, b = moisture_parameters(q, (T[:-1] + T[1:]) / 2)
            flux = np.zeros(n + 1)
            flux[1:-1] = faces[1:-1] * A * np.diff(phi(C, b)) / dx
            flux[-1] = R * HM * (Ca - C[-1])
            dC = np.diff(flux) / (R * R * vol)
        return np.r_[flux_div(T, k, Ta, HT, R) / cap, dC]

    mask = lil_matrix((2 * n, 2 * n), dtype=int)
    for i in range(n):
        for j in range(max(0, i - 1), min(n, i + 2)):
            mask[i, j] = mask[i, n + j] = mask[n + i, j] = mask[n + i, n + j] = 1

    def event(t, y):
        return np.max(y[n:]) - TARGET

    event.terminal = True
    event.direction = -1
    return x, vol, rhs, mask.tocsr(), event


class Run:
    def __init__(self, q, n=81, rtol=1e-7, max_step=60, moisture_flux="integrated"):
        start = time.perf_counter()
        self.q, self.n, self.rtol = q, n, rtol
        self.moisture_flux = moisture_flux
        self.x, self.vol, rhs, sparsity, event = model(q, n, moisture_flux)
        self.rhs = rhs
        y0 = np.r_[np.full(n, 28.0), np.full(n, 2.55)]
        kw = dict(
            method="BDF",
            rtol=rtol,
            atol=np.r_[np.full(n, rtol * 0.1), np.full(n, rtol * 0.001)],
            max_step=max_step,
            jac_sparsity=sparsity,
            dense_output=True,
        )
        self.main = solve_ivp(
            rhs,
            (0, 1800 if q == 1 else 14 * 86400),
            y0,
            events=None if q == 1 else event,
            **kw,
        )
        assert self.main.success, self.main.message
        self.tail = None
        if q != 1:
            assert len(self.main.t_events[0]) == 1, "Threshold not reached in 14 days"
            self.event_s = float(self.main.t_events[0][0])
            self.end_s = int(math.floor(self.event_s) + 1)
            self.tail = solve_ivp(
                rhs, (self.event_s, self.end_s), self.main.y[:, -1], **kw
            )
            assert self.tail.success
            self.end_max = float(self.tail.y[n:, -1].max())
            self.prev_max = float(self.main.sol(self.end_s - 1)[n:].max())
            assert self.end_max < TARGET and self.prev_max >= TARGET, (
                self.end_max,
                self.prev_max,
            )
        else:
            self.event_s = None
            self.end_s = 1800
        self.elapsed = time.perf_counter() - start
        self.checks = self.validate()
        print(json.dumps(self.metadata()), flush=True)

    def sample(self, t):
        t = np.atleast_1d(t).astype(float)
        a = np.empty((2 * self.n, len(t)))
        inside = t <= self.main.t[-1]
        if inside.any():
            a[:, inside] = self.main.sol(t[inside])
        if (~inside).any():
            assert self.tail is not None and t.max() <= self.end_s
            a[:, ~inside] = self.tail.sol(t[~inside])
        return a

    def physical(self, t, cm):
        t = np.atleast_1d(t).astype(float)
        cm = np.asarray(cm)
        a = self.sample(t)
        rr = radius(self.q, t) * 100
        T, C = np.full((len(t), len(cm)), np.nan), np.full((len(t), len(cm)), np.nan)
        for j in range(len(t)):
            valid = cm <= rr[j] + 1e-12
            T[j, valid] = np.interp(cm[valid] / rr[j], self.x, a[: self.n, j])
            C[j, valid] = np.interp(cm[valid] / rr[j], self.x, a[self.n :, j])
        return T, C

    def validate(self):
        states = self.main.y if self.tail is None else np.c_[self.main.y, self.tail.y]
        T, C = states[: self.n], states[self.n :]
        tcheck = np.unique(np.r_[np.arange(0, self.end_s + 1, 60), self.end_s])
        sampled = self.sample(tcheck)
        Tmin = float(min(T.min(), sampled[: self.n].min()))
        Tmax = float(max(T.max(), sampled[: self.n].max()))
        Cmin = float(min(C.min(), sampled[self.n :].min()))
        Cmax = float(max(C.max(), sampled[self.n :].max()))
        initial_ok = np.array_equal(
            self.sample([0])[:, 0], np.r_[np.full(self.n, 28.0), np.full(self.n, 2.55)]
        )
        bounds_ok = (
            Tmin >= min(28, float(ENV[:, 1].min())) - 1e-6
            and Tmax <= max(28, float(ENV[:, 1].max())) + 1e-6
            and Cmin > 0
            and Cmax <= 2.55 + 1e-8
        )
        assert initial_ok and bounds_ok, (Tmin, Tmax, Cmin, Cmax)
        conservation = []
        for tt in [100.0, min(1800.0, self.end_s), float(self.end_s)]:
            yy = self.sample([tt])[:, 0]
            dy = self.rhs(tt, yy)
            cap, _, _ = props(self.q, yy[: self.n], yy[self.n :])
            R = float(radius(self.q, tt))
            lhsT = float(np.sum(self.vol * R**2 * cap * dy[: self.n]))
            rhsT = (
                R * HT * (float(np.interp(tt, ENV[:, 0], ENV[:, 1])) - yy[self.n - 1])
            )
            lhsC = float(np.sum(self.vol * R**2 * dy[self.n :]))
            rhsC = R * HM * (float(np.interp(tt, ENV[:, 0], ENV[:, 2])) - yy[-1])
            conservation.append(
                {
                    "time_s": tt,
                    "heat_residual": float(lhsT - rhsT),
                    "moisture_residual": float(lhsC - rhsC),
                }
            )
            assert abs(lhsT - rhsT) < 1e-10 and abs(lhsC - rhsC) < 1e-18
        return dict(
            initial_exact=bool(initial_ok),
            physical_bounds=bool(bounds_ok),
            temperature_min=Tmin,
            temperature_max=Tmax,
            moisture_min=Cmin,
            moisture_max=Cmax,
            discrete_flux_balance=conservation,
            inspection="accepted internal steps and 60-second dense samples; no clipping",
        )

    def metadata(self):
        d = dict(
            problem=self.q,
            nodes=self.n,
            moisture_flux=self.moisture_flux,
            rtol=self.rtol,
            end_s=self.end_s,
            end_h=self.end_s / 3600,
            event_s=self.event_s,
            event_h=None if self.event_s is None else self.event_s / 3600,
            nfev=self.main.nfev,
            njev=self.main.njev,
            nlu=self.main.nlu,
            accepted_steps=len(self.main.t) - 1,
            elapsed_s=self.elapsed,
            checks=self.checks,
        )
        if self.q != 1:
            d.update(
                endpoint_max_C=self.end_max,
                previous_second=self.end_s - 1,
                previous_second_max_C=self.prev_max,
            )
        return d


def clean(v):
    if isinstance(v, np.ndarray):
        return clean(v.tolist())
    if isinstance(v, (np.floating, float)):
        return None if not np.isfinite(v) else float(v)
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, dict):
        return {str(k): clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [clean(x) for x in v]
    return v


def write_json(name, data):
    text = json.dumps(clean(data), ensure_ascii=False, indent=None, allow_nan=False)
    (WORK / name).write_text(text, encoding="utf-8")
    if WORK != DEST:
        shutil.copy2(WORK / name, DEST / name)


def table(run, times, cm, field):
    T, C = run.physical(times, cm)
    a = run.sample(times)
    d = dict(
        time_s=np.asarray(times),
        time_h=np.asarray(times) / 3600,
        radius_positions_cm=cm,
        values=T if field == "temperature" else C,
        units="degC" if field == "temperature" else "kg/kg",
    )
    if run.q == 4:
        d.update(
            surface_values=a[run.n - 1 if field == "temperature" else -1],
            surface_radius_cm=radius(4, np.asarray(times)) * 100,
        )
    return d


def complete(run, times, name):
    cm = np.linspace(0, 2, 21)
    T, C = run.physical(times, cm)
    a = run.sample(times)
    data = dict(
        time_s=times,
        radius_positions_cm=cm,
        temperature_C=T,
        moisture_kg_kg=C,
        surface_temperature_C=a[run.n - 1],
        surface_moisture_kg_kg=a[-1],
        surface_radius_cm=radius(run.q, np.asarray(times)) * 100,
        metadata=run.metadata(),
    )
    write_json(name, data)


def compare(coarse, fine):
    times = np.unique(
        np.r_[
            0,
            100,
            300,
            600,
            900,
            1200,
            1500,
            1800,
            np.arange(21600, min(coarse.end_s, fine.end_s), 21600),
            min(coarse.end_s, fine.end_s),
        ]
    )
    vals = []
    for run in (coarse, fine):
        a = run.sample(times)
        grid = np.linspace(0, 1, 41)
        vals.append(
            np.stack(
                [
                    np.stack(
                        [
                            np.interp(grid, run.x, a[j * run.n : (j + 1) * run.n, i])
                            for i in range(len(times))
                        ]
                    )
                    for j in (0, 1)
                ]
            )
        )
    dif = np.abs(vals[0] - vals[1])
    d = dict(
        coarse_nodes=coarse.n,
        fine_nodes=fine.n,
        coarse_rtol=coarse.rtol,
        fine_rtol=fine.rtol,
        max_temperature_difference=float(dif[0].max()),
        max_moisture_difference=float(dif[1].max()),
        comparison_times_s=times.tolist(),
        comparison_grid="41 common normalized material coordinates x=0..1",
    )
    if coarse.event_s is not None:
        d.update(
            event_time_difference_s=coarse.event_s - fine.event_s,
            relative_event_difference=abs(coarse.event_s - fine.event_s) / fine.event_s,
            integer_end_difference_s=coarse.end_s - fine.end_s,
        )
    return d


def outputs(summary, runs):
    q1, q3, q4 = runs[1], runs[3], runs[4]
    times1 = np.array([100, 300, 600, 900, 1200, 1500, 1800])
    times2 = np.arange(1800, 10801, 1800)
    cm = [0, 0.5, 1, 1.5, 2]
    for num, run, ts, field in [
        (1, q1, times1, "temperature"),
        (2, q1, times1, "moisture"),
        (3, q3, times2, "temperature"),
        (4, q3, times2, "moisture"),
    ]:
        summary["tables"][str(num)] = table(run, ts, cm, field)
    for num, run in [(5, q3), (6, q4)]:
        ts = np.r_[np.arange(21600, run.end_s, 21600), run.end_s]
        summary["tables"][str(num)] = table(
            run, ts, [0, 0.5, 1, 1.5] if run.q == 4 else cm, "moisture"
        )
    summary["baselines"]["2"] = {
        "source_problem": 3,
        "end_s": 10800,
        "end_h": 3,
        "comment": "Same PDE and initial conditions as Q3, exact dense-output prefix of that integration.",
    }
    summary["radius_reduction_at_q4_end"] = 1 - float(radius(4, q4.end_s)) / 0.02
    summary["q4_vs_q3_duration_ratio"] = q4.end_s / q3.end_s
    write_json("summary.json", summary)
    complete(q1, np.arange(1801), "result1_full.json")
    complete(q3, np.arange(10801), "result2_full.json")
    for run in [q3, q4]:
        complete(
            run,
            np.r_[np.arange(0, run.end_s, 60), run.end_s],
            f"result{run.q}_full.json",
        )
    plots = {}
    for q, run in runs.items():
        tt = np.unique(
            np.r_[np.arange(0, run.end_s + 1, 10 if q == 1 else 60), run.end_s]
        )
        aa = run.sample(tt)
        plots.update(
            {
                f"q{q}_time_s": tt,
                f"q{q}_center_T": aa[0],
                f"q{q}_surface_T": aa[run.n - 1],
                f"q{q}_center_C": aa[run.n],
                f"q{q}_surface_C": aa[-1],
                f"q{q}_radius_cm": radius(q, tt) * 100,
            }
        )
        rt = (
            times1
            if q == 1
            else np.unique(
                np.r_[1800, 10800, np.arange(21600, run.end_s, 21600), run.end_s]
            )
        )
        a = run.sample(rt)
        plots.update(
            {
                f"q{q}_profile_times_s": rt,
                f"q{q}_profile_radius_cm": radius(q, rt)[:, None]
                * run.x[None, :]
                * 100,
                f"q{q}_profile_T": a[: run.n].T,
                f"q{q}_profile_C": a[run.n :].T,
            }
        )
    plots["environment"] = ENV
    plots["radius_input"] = RAD
    np.savez_compressed(WORK / "plot_data.npz", **plots)
    if WORK != DEST:
        shutil.copy2(WORK / "plot_data.npz", DEST / "plot_data.npz")


def verify_phi():
    checks = []
    for b in [0.89, 0.45, 0.30]:
        for C in [0.01963, 0.05, 0.15, 0.5, 2.55]:
            h = C * 1e-4
            deriv = (
                -phi(C + 2 * h, b)
                + 8 * phi(C + h, b)
                - 8 * phi(C - h, b)
                + phi(C - 2 * h, b)
            ) / (12 * h)
            exact = np.exp(-b / C)
            rel = abs(deriv - exact) / exact
            assert rel < 1e-7, (b, C, rel)
            checks.append(
                dict(
                    b=b,
                    C=C,
                    numerical_derivative=float(deriv),
                    exact_derivative=float(exact),
                    relative_error=float(rel),
                )
            )
        for lo, hi in [(0.01963, 0.05), (0.05, 0.15), (0.15, 2.55)]:
            v = phi(hi, b) - phi(lo, b)
            integ, err = quad(
                lambda c: np.exp(-b / c), lo, hi, epsabs=1e-15, epsrel=1e-12
            )
            assert abs(v - integ) < 1e-12 * max(abs(integ), 1e-10)
            checks.append(
                dict(
                    b=b,
                    interval=[lo, hi],
                    phi_difference=float(v),
                    quad=float(integ),
                    absolute_error=float(abs(v - integ)),
                )
            )
    return checks


def validate_outputs():
    report = {}
    for q in [1, 2, 3, 4]:
        r = json.loads((WORK / f"result{q}_full.json").read_text(encoding="utf-8"))
        ts = np.asarray(r["time_s"])
        T = np.asarray(r["temperature_C"], dtype=float)
        C = np.asarray(r["moisture_kg_kg"], dtype=float)
        assert T.shape == C.shape == (len(ts), 21)
        assert np.array_equal(T[0], np.full(21, 28.0)) and np.array_equal(
            C[0], np.full(21, 2.55)
        )
        assert np.all(np.diff(ts) > 0)
        if q in (1, 2):
            assert np.all(np.diff(ts) == 1) and ts[-1] == (1800 if q == 1 else 10800)
        else:
            assert np.all(np.diff(ts)[:-1] == 60) and 0 < np.diff(ts)[-1] <= 60
        if q == 4:
            expected = (
                np.asarray(r["radius_positions_cm"])[None, :]
                > np.asarray(r["surface_radius_cm"])[:, None] + 1e-12
            )
            assert np.array_equal(np.isnan(C), expected) and np.array_equal(
                np.isnan(T), expected
            )
        else:
            assert np.isfinite(T).all() and np.isfinite(C).all()
        report[str(q)] = dict(
            rows=len(ts),
            columns=21,
            initial_row_exact=True,
            time_grid_valid=True,
            outside_domain_null_count=int(np.isnan(C).sum()),
        )
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input-dir",
        type=Path,
        required=True,
        help="A problem directory containing the attachments subdirectory",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path(__file__).resolve().parent
    )
    args = parser.parse_args()
    configure(args.input_dir, args.output_dir)
    summary = dict(
        method=dict(
            spatial="conservative radial finite volume; endpoints included; midpoint faces; harmonic thermal conductivity; nonlinear integrated moisture flux",
            moisture_face_flux="x_face*A(T_face)*(Phi(C_right)-Phi(C_left))/dx, T_face=(T_left+T_right)/2",
            phi="Phi(C)=C*exp(-b/C)+b*Ei(-b/C); derivative exp(-b/C)",
            time="solve_ivp BDF with sparse Jacobian pattern and dense output",
            nodes={},
            rtol=1e-7,
            temperature_atol=1e-8,
            moisture_atol=1e-10,
            max_step_s=60,
            initial_temperature_C=28,
            initial_moisture_kg_kg=2.55,
            heat_transfer_coefficient=HT,
            mass_transfer_coefficient=HM,
            threshold=TARGET,
            threshold_rule="first integer second strictly after continuous max(C)=0.15 crossing, verified against preceding integer second",
            shrinkage="uniform material shrinkage x=r/R(t); fixed material mesh, effective dry-basis C has no separate dilution term",
            interpolation="linear between input data; endpoint values outside input range",
            scope="radial-only; ignore axial transport and evaporation latent heat; Q2/Q3/Q4 retain HT=25 and HM=8e-7 because appendices 3/4 provide no replacement values",
            versions=dict(numpy=np.__version__, scipy=scipy.__version__),
        ),
        inputs=dict(
            environment_rows=len(ENV),
            environment_first=ENV[0],
            environment_last=ENV[-1],
            radius_rows=len(RAD),
            radius_first=RAD[0],
            radius_last=RAD[-1],
        ),
        baselines={},
        tables={},
        convergence={},
        time_tolerance={},
        integrated_flux_verification=verify_phi(),
        spatial_converged=False,
        verification_complete=False,
    )
    runs = {}
    meshes = {}
    for q in [1, 3, 4]:
        meshes[q] = [Run(q, n=n) for n in [41, 81, 161, 321]]
        comp = compare(meshes[q][-2], meshes[q][-1])
        if q != 1 and comp["relative_event_difference"] >= 0.001:
            meshes[q].append(Run(q, n=641))
        runs[q] = meshes[q][-1]
        summary["baselines"][str(q)] = runs[q].metadata()
        summary["method"]["nodes"][str(q)] = runs[q].n
        summary["convergence"][str(q)] = {
            "runs": [r.metadata() for r in meshes[q]],
            "comparisons": [
                compare(a, b) for a, b in zip(meshes[q][:-1], meshes[q][1:])
            ],
        }
        last = summary["convergence"][str(q)]["comparisons"][-1]
        passed = last.get("relative_event_difference", 0) < 0.001
        summary["convergence"][str(q)]["spatial_converged"] = passed if q != 1 else None
        summary["convergence"][str(q)][
            "criterion"
        ] = "consecutive event-time relative difference below 0.001 for drying endpoints; Q1 reports actual field differences without claiming four-decimal field convergence"
        write_json("summary.json", summary)
    summary["spatial_converged"] = all(
        summary["convergence"][str(q)]["spatial_converged"] for q in [3, 4]
    )
    outputs(summary, runs)
    print("INTEGRATED_OUTPUTS_READY", flush=True)
    summary["harmonic_diagnostic"] = {}
    for q in [1, 3, 4]:
        hs = [Run(q, n=n, moisture_flux="harmonic") for n in [321, 641]]
        summary["harmonic_diagnostic"][str(q)] = {
            "runs": [r.metadata() for r in hs],
            "321_vs_641": compare(*hs),
            "harmonic641_vs_final_integrated": compare(hs[-1], runs[q]),
        }
        write_json("summary.json", summary)
    strict = Run(3, n=runs[3].n, rtol=1e-9, max_step=30)
    summary["time_tolerance"]["3"] = {
        "run": strict.metadata(),
        "base_vs_strict": compare(runs[3], strict),
    }
    summary["verification_complete"] = True
    summary["output_validation"] = validate_outputs()
    summary["numerical_limitations"] = [
        "Discrete flux-balance identities verify cancellation of internal numerical face fluxes only. They do not establish conservation of physical total water mass or total energy for moisture-dependent density/capacity or imposed material shrinkage.",
        "No experimental drying profiles are supplied for calibration or validation. Radius observations are imposed as model input.",
        "The reported endpoint criterion is successive-grid agreement below 0.1%, not rigorous discretization-error bounds or four-decimal accuracy of every field entry.",
        "Q4 results depend on the stated uniform material shrinkage effective dry-basis model and prescribed radius extension.",
    ]
    write_json("summary.json", summary)
    src = Path(__file__).resolve()
    if src != WORK / src.name:
        shutil.copy2(src, WORK / src.name)
    manifest = {
        p.name: dict(
            bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()
        )
        for p in WORK.iterdir()
        if p.is_file()
        and p.suffix in (".json", ".npz", ".py")
        and p.name != "manifest.json"
    }
    write_json("manifest.json", manifest)
    print("ALL_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
