from pathlib import Path
import json, numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

DATA = Path(__file__).resolve().parent
OUT = DATA / "figures"
OUT.mkdir(exist_ok=True)
for f in [r"C:\Windows\Fonts\simsun.ttc", r"C:\Windows\Fonts\consola.ttf"]:
    fm.fontManager.addfont(f)
plt.rcParams.update(
    {
        "font.family": ["Consolas", "SimSun"],
        "axes.unicode_minus": False,
        "font.size": 10,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.7,
        "lines.linewidth": 1.6,
        "savefig.facecolor": "white",
    }
)
z = np.load(DATA / "plot_data.npz")
env = z["environment"]
rad = z["radius_input"]
blue = "#205F85"
orange = "#B45D35"
gray = "#555555"
fig, ax = plt.subplots(1, 2, figsize=(9.6, 3.1))
a = ax[0]
twin = a.twinx()
l1 = a.plot(env[:, 0] / 3600, env[:, 1], c=blue, label="烘房温度")
l2 = twin.plot(env[:, 0] / 3600, env[:, 2], c=orange, label="烘房水分浓度")
a.set(xlabel="时间 / h", ylabel="温度 / ℃", title="(a) 烘房环境")
twin.set_ylabel("水分浓度 / (kg/kg)")
a.legend(l1 + l2, [l.get_label() for l in l1 + l2], loc="lower right", frameon=False)
a.grid(alpha=0.15)
ax[1].plot(rad[:, 0] / 3600, rad[:, 1], c=blue)
ax[1].set(xlabel="时间 / h", ylabel="半径 / cm", title="(b) 半径观测")
ax[1].grid(alpha=0.15)
fig.tight_layout(w_pad=2.1)
fig.savefig(OUT / "inputs.png", dpi=260)
plt.close(fig)
fig, ax = plt.subplots(2, 2, figsize=(9.6, 5.5))
for row, q in enumerate([1, 3]):
    mask = z[f"q{q}_time_s"] <= (1800 if q == 1 else 10800)
    ts = z[f"q{q}_time_s"][mask] / 3600
    for col, field in enumerate(["T", "C"]):
        a = ax[row, col]
        a.plot(ts, z[f"q{q}_center_{field}"][mask], c=blue, label="中心")
        a.plot(ts, z[f"q{q}_surface_{field}"][mask], c=orange, label="表面")
        a.set(
            xlabel="时间 / h",
            ylabel="温度 / ℃" if field == "T" else "水分浓度 / (kg/kg)",
            title=f"({chr(97+row*2+col)}) 问题" + ("一" if q == 1 else "二"),
        )
        a.grid(alpha=0.15)
        a.legend(frameon=False, loc="best")
fig.tight_layout(h_pad=1.3, w_pad=2.0)
fig.savefig(OUT / "short_term.png", dpi=260)
plt.close(fig)
fig, ax = plt.subplots(1, 2, figsize=(9.6, 3.2))
for a, q, lab in zip(ax, [3, 4], ["(a) 固定半径", "(b) 给定半径收缩"]):
    ts = z[f"q{q}_time_s"] / 3600
    a.plot(ts, z[f"q{q}_center_C"], c=blue, label="中心")
    a.plot(ts, z[f"q{q}_surface_C"], c=orange, label="表面")
    a.axhline(0.15, c=gray, ls="--", lw=1, label="达标阈值")
    a.set(xlabel="时间 / h", ylabel="水分浓度 / (kg/kg)", title=lab, ylim=(0, 2.7))
    a.grid(alpha=0.15)
    a.legend(frameon=False, loc="upper right")
    a.plot(ts[-1], z[f"q{q}_center_C"][-1], "o", c=blue, ms=3.5)
fig.tight_layout(w_pad=2.0)
fig.savefig(OUT / "drying.png", dpi=260)
plt.close(fig)
print("Saved figures", [p.name for p in OUT.glob("*.png")])
