import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";

// Dependency: @oai/artifact-tool 2.8.58 or later.
// Usage: node export_results.mjs [data-directory]
// The optional directory must contain result1_full.json through result4_full.json.
// When omitted, the script reads and writes files beside export_results.mjs.

async function loadArtifactTool() {
  try {
    return await import("@oai/artifact-tool");
  } catch (directError) {
    try {
      const requireFromCwd = createRequire(path.join(process.cwd(), "package.json"));
      const resolved = requireFromCwd.resolve("@oai/artifact-tool");
      return await import(pathToFileURL(resolved).href);
    } catch {
      throw new Error(
        "Cannot load @oai/artifact-tool. Install or expose it in node_modules before running this script.",
        { cause: directError },
      );
    }
  }
}

const { SpreadsheetFile, Workbook } = await loadArtifactTool();
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(process.argv[2] ?? scriptDir);
const chineseFont = "SimSun";
const latinFont = "Consolas";

const workbookConfigs = [
  {
    index: 1,
    sheets: [
      ["\u6e29\u5ea6", "temperature_C"],
      ["\u6c34\u5206\u6d53\u5ea6", "moisture_kg_kg"],
    ],
  },
  {
    index: 2,
    sheets: [
      ["\u6e29\u5ea6", "temperature_C"],
      ["\u6c34\u5206\u6d53\u5ea6", "moisture_kg_kg"],
    ],
  },
  { index: 3, sheets: [["Sheet1", "moisture_kg_kg"]] },
  { index: 4, sheets: [["Sheet1", "moisture_kg_kg"]] },
];

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function maxIgnoringNull(values) {
  let maximum = -Infinity;
  for (const value of values) {
    if (value !== null && value > maximum) maximum = value;
  }
  return maximum;
}

function validateSource(source, index) {
  assert(source.time_s.length > 0, `result${index}: empty time axis`);
  assert(source.radius_positions_cm.length === 21, `result${index}: expected 21 radius positions`);
  assert(
    source.radius_positions_cm.every((value, i) => Math.abs(value - i / 10) < 1e-12),
    `result${index}: radius positions must be 0.0 to 2.0 cm in 0.1 cm steps`,
  );
  for (const key of ["temperature_C", "moisture_kg_kg"]) {
    assert(source[key].length === source.time_s.length, `result${index}/${key}: row count mismatch`);
    assert(source[key].every((row) => row.length === 21), `result${index}/${key}: column count mismatch`);
  }
  if (index >= 3) {
    assert(maxIgnoringNull(source.moisture_kg_kg.at(-1)) < 0.15, `result${index}: endpoint max C is not below 0.15`);
  }
}

function populateSheet(sheet, source, dataKey) {
  const rowCount = source.time_s.length;
  const lastRow = rowCount + 1;
  const matrix = source[dataKey];
  sheet.getRange("A1").write([["\u65f6\u95f4", ...source.radius_positions_cm]]);
  sheet.getRange("A2").write(source.time_s.map((time, i) => [time, ...matrix[i]]));

  const usedRange = sheet.getRange(`A1:V${lastRow}`);
  usedRange.format.font = { name: latinFont, size: 10, color: "#222222" };
  usedRange.format.verticalAlignment = "center";
  sheet.getRange("A1:V1").format = {
    fill: "#E7E6E6",
    font: { name: latinFont, size: 10, bold: true, color: "#222222" },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    borders: { bottom: { style: "thin", color: "#A6A6A6" } },
  };
  sheet.getRange("A1").format.font = { name: chineseFont, size: 10, bold: true, color: "#222222" };
  sheet.getRange(`A2:A${lastRow}`).format.numberFormat = "0";
  sheet.getRange("B1:V1").format.numberFormat = "0.0";
  sheet.getRange(`B2:V${lastRow}`).format.numberFormat = "0.0000";
  sheet.getRange(`A1:A${lastRow}`).format.columnWidth = 12;
  sheet.getRange(`B1:V${lastRow}`).format.columnWidth = 11;
  sheet.getRange("A1:V1").format.rowHeight = 20;
  sheet.freezePanes.freezeRows(1);
  sheet.freezePanes.freezeColumns(1);
}

for (const config of workbookConfigs) {
  const jsonPath = path.join(dataDir, `result${config.index}_full.json`);
  const source = JSON.parse(await fs.readFile(jsonPath, "utf8"));
  validateSource(source, config.index);

  const workbook = Workbook.create();
  for (const [sheetName, dataKey] of config.sheets) {
    populateSheet(workbook.worksheets.add(sheetName), source, dataKey);
  }
  workbook.recalculate();
  const output = await SpreadsheetFile.exportXlsx(workbook);
  const outputPath = path.join(dataDir, `result${config.index}.xlsx`);
  await output.save(outputPath);
  // artifact-tool may emit an inspection sidecar during export; it is not a deliverable.
  await fs.rm(`${outputPath}.inspect.ndjson`, { force: true });
  console.log(`Created ${outputPath}`);
}
